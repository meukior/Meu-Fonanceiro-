import { Hono } from "hono";
import {
  exchangeCodeForSessionToken,
  getOAuthRedirectUrl,
  authMiddleware,
  deleteSession,
  MOCHA_SESSION_TOKEN_COOKIE_NAME,
} from "@getmocha/users-service/backend";
import { getCookie, setCookie } from "hono/cookie";
import { CreateTransactionSchema, CreateSavingsSchema } from "@/shared/types";

const app = new Hono<{ Bindings: Env }>();

// Auth endpoints
app.get("/api/oauth/google/redirect_url", async (c) => {
  const redirectUrl = await getOAuthRedirectUrl("google", {
    apiUrl: c.env.MOCHA_USERS_SERVICE_API_URL,
    apiKey: c.env.MOCHA_USERS_SERVICE_API_KEY,
  });

  return c.json({ redirectUrl }, 200);
});

app.post("/api/sessions", async (c) => {
  const body = await c.req.json();

  if (!body.code) {
    return c.json({ error: "No authorization code provided" }, 400);
  }

  const sessionToken = await exchangeCodeForSessionToken(body.code, {
    apiUrl: c.env.MOCHA_USERS_SERVICE_API_URL,
    apiKey: c.env.MOCHA_USERS_SERVICE_API_KEY,
  });

  setCookie(c, MOCHA_SESSION_TOKEN_COOKIE_NAME, sessionToken, {
    httpOnly: true,
    path: "/",
    sameSite: "none",
    secure: true,
    maxAge: 60 * 24 * 60 * 60,
  });

  return c.json({ success: true }, 200);
});

app.get("/api/users/me", authMiddleware, async (c) => {
  return c.json(c.get("user"));
});

app.get("/api/logout", async (c) => {
  const sessionToken = getCookie(c, MOCHA_SESSION_TOKEN_COOKIE_NAME);

  if (typeof sessionToken === "string") {
    await deleteSession(sessionToken, {
      apiUrl: c.env.MOCHA_USERS_SERVICE_API_URL,
      apiKey: c.env.MOCHA_USERS_SERVICE_API_KEY,
    });
  }

  setCookie(c, MOCHA_SESSION_TOKEN_COOKIE_NAME, "", {
    httpOnly: true,
    path: "/",
    sameSite: "none",
    secure: true,
    maxAge: 0,
  });

  return c.json({ success: true }, 200);
});

// Transaction endpoints
app.get("/api/transactions", authMiddleware, async (c) => {
  const user = c.get("user")!;
  const month = c.req.query("month");
  const year = c.req.query("year");

  let query = "SELECT * FROM transactions WHERE user_id = ?";
  const params: any[] = [user.id];

  if (month && year) {
    query += " AND month = ? AND year = ?";
    params.push(parseInt(month), parseInt(year));
  }

  query += " ORDER BY created_at DESC";

  const { results } = await c.env.DB.prepare(query).bind(...params).all();

  return c.json(results);
});

app.post("/api/transactions", authMiddleware, async (c) => {
  const user = c.get("user")!;
  const body = await c.req.json();

  const validation = CreateTransactionSchema.safeParse(body);
  if (!validation.success) {
    return c.json({ error: validation.error }, 400);
  }

  const data = validation.data;

  const result = await c.env.DB.prepare(
    "INSERT INTO transactions (user_id, amount, type, description, month, year) VALUES (?, ?, ?, ?, ?, ?)"
  )
    .bind(user.id, data.amount, data.type, data.description || null, data.month, data.year)
    .run();

  const { results } = await c.env.DB.prepare(
    "SELECT * FROM transactions WHERE id = ?"
  )
    .bind(result.meta.last_row_id)
    .all();

  return c.json(results[0], 201);
});

app.delete("/api/transactions/:id", authMiddleware, async (c) => {
  const user = c.get("user")!;
  const id = c.req.param("id");

  const { results } = await c.env.DB.prepare(
    "SELECT * FROM transactions WHERE id = ? AND user_id = ?"
  )
    .bind(id, user.id)
    .all();

  if (!results.length) {
    return c.json({ error: "Transaction not found" }, 404);
  }

  await c.env.DB.prepare("DELETE FROM transactions WHERE id = ?").bind(id).run();

  return c.json({ success: true }, 200);
});

// Savings endpoints
app.get("/api/savings", authMiddleware, async (c) => {
  const user = c.get("user")!;

  const { results } = await c.env.DB.prepare(
    "SELECT * FROM savings WHERE user_id = ? ORDER BY created_at DESC"
  )
    .bind(user.id)
    .all();

  return c.json(results);
});

app.post("/api/savings", authMiddleware, async (c) => {
  const user = c.get("user")!;
  const body = await c.req.json();

  const validation = CreateSavingsSchema.safeParse(body);
  if (!validation.success) {
    return c.json({ error: validation.error }, 400);
  }

  const data = validation.data;

  const result = await c.env.DB.prepare(
    "INSERT INTO savings (user_id, amount, description) VALUES (?, ?, ?)"
  )
    .bind(user.id, data.amount, data.description || null)
    .run();

  const { results } = await c.env.DB.prepare(
    "SELECT * FROM savings WHERE id = ?"
  )
    .bind(result.meta.last_row_id)
    .all();

  return c.json(results[0], 201);
});

app.delete("/api/savings/:id", authMiddleware, async (c) => {
  const user = c.get("user")!;
  const id = c.req.param("id");

  const { results } = await c.env.DB.prepare(
    "SELECT * FROM savings WHERE id = ? AND user_id = ?"
  )
    .bind(id, user.id)
    .all();

  if (!results.length) {
    return c.json({ error: "Savings not found" }, 404);
  }

  await c.env.DB.prepare("DELETE FROM savings WHERE id = ?").bind(id).run();

  return c.json({ success: true }, 200);
});

export default app;

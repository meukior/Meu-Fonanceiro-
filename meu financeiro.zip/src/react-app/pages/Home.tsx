import { useAuth } from "@getmocha/users-service/react";
import { Loader2 } from "lucide-react";
import Dashboard from "@/react-app/components/Dashboard";
import LoginScreen from "@/react-app/components/LoginScreen";

export default function Home() {
  const { user, isPending } = useAuth();

  if (isPending) {
    return (
      <div className="flex flex-col items-center justify-center min-h-screen bg-gradient-to-br from-emerald-50 to-teal-50 dark:from-gray-900 dark:to-gray-800">
        <div className="animate-spin">
          <Loader2 className="w-10 h-10 text-emerald-600 dark:text-emerald-400" />
        </div>
      </div>
    );
  }

  if (!user) {
    return <LoginScreen />;
  }

  return <Dashboard />;
}

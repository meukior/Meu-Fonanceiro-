import { useEffect, useState } from "react";
import { PiggyBank, Plus, Trash2 } from "lucide-react";
import type { Savings } from "@/shared/types";

interface SavingsPanelProps {
  refreshKey: number;
  onSavingsDeleted: () => void;
  onAddSavings: () => void;
}

export default function SavingsPanel({
  refreshKey,
  onSavingsDeleted,
  onAddSavings,
}: SavingsPanelProps) {
  const [savings, setSavings] = useState<Savings[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchSavings = async () => {
      setLoading(true);
      try {
        const response = await fetch("/api/savings");
        const data = await response.json();
        setSavings(data);
      } catch (error) {
        console.error("Error fetching savings:", error);
      } finally {
        setLoading(false);
      }
    };

    fetchSavings();
  }, [refreshKey]);

  const handleDelete = async (id: number) => {
    if (!confirm("Deseja excluir esta economia?")) return;

    try {
      await fetch(`/api/savings/${id}`, { method: "DELETE" });
      onSavingsDeleted();
    } catch (error) {
      console.error("Error deleting savings:", error);
    }
  };

  const total = savings.reduce((sum, s) => sum + s.amount, 0);

  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat("pt-BR", {
      style: "currency",
      currency: "BRL",
    }).format(value);
  };

  return (
    <div className="bg-white/80 dark:bg-gray-800/80 backdrop-blur-sm rounded-2xl shadow-lg border border-white/20 dark:border-gray-700 overflow-hidden transition-colors duration-300">
      <div className="p-6 border-b border-gray-100 dark:border-gray-700">
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-lg font-semibold text-gray-900 dark:text-white">Cofrinho</h3>
          <button
            onClick={onAddSavings}
            className="flex items-center gap-2 px-4 py-2 bg-gradient-to-r from-violet-500 to-purple-600 text-white rounded-xl hover:shadow-lg transition-all duration-200 hover:scale-105 text-sm font-medium"
          >
            <Plus className="w-4 h-4" />
            Adicionar
          </button>
        </div>

        <div className="bg-gradient-to-br from-violet-500 to-purple-600 rounded-2xl p-6 text-white">
          <div className="flex items-center gap-3 mb-3">
            <div className="w-12 h-12 rounded-xl bg-white/20 backdrop-blur-sm flex items-center justify-center">
              <PiggyBank className="w-6 h-6" />
            </div>
            <div>
              <p className="text-violet-100 text-sm">Total Guardado</p>
              <p className="text-2xl font-bold">{formatCurrency(total)}</p>
            </div>
          </div>
        </div>
      </div>

      <div className="divide-y divide-gray-100 dark:divide-gray-700 max-h-[400px] overflow-y-auto">
        {loading ? (
          <div className="p-8 text-center text-gray-500 dark:text-gray-400">Carregando...</div>
        ) : savings.length === 0 ? (
          <div className="p-8 text-center text-gray-500 dark:text-gray-400">
            Comece a guardar dinheiro!
          </div>
        ) : (
          savings.map((saving) => (
            <div
              key={saving.id}
              className="p-4 hover:bg-gray-50 dark:hover:bg-gray-700 transition-colors flex items-center justify-between group"
            >
              <div className="flex-1">
                <p className="font-medium text-gray-900 dark:text-white">
                  {saving.description || "Economia"}
                </p>
                <p className="text-sm text-gray-500 dark:text-gray-400">
                  {new Date(saving.created_at).toLocaleDateString("pt-BR")}
                </p>
              </div>
              <div className="flex items-center gap-3">
                <p className="text-lg font-bold text-violet-600">
                  {formatCurrency(saving.amount)}
                </p>
                <button
                  onClick={() => handleDelete(saving.id)}
                  className="p-2 text-gray-400 hover:text-red-600 hover:bg-red-50 dark:hover:bg-red-900/20 rounded-lg transition-colors opacity-0 group-hover:opacity-100"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
            </div>
          ))
        )}
      </div>
    </div>
  );
}

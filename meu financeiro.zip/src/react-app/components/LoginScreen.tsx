import { useAuth } from "@getmocha/users-service/react";
import { PiggyBank, TrendingUp, TrendingDown, Sparkles } from "lucide-react";
import InstallButton from "./InstallButton";

export default function LoginScreen() {
  const { redirectToLogin } = useAuth();

  return (
    <div className="min-h-screen bg-gradient-to-br from-emerald-50 via-teal-50 to-cyan-50 dark:from-gray-900 dark:via-gray-800 dark:to-gray-900 flex items-center justify-center p-4 transition-colors duration-300">
      <div className="max-w-md w-full">
        <div className="text-center mb-8">
          <div className="inline-flex items-center justify-center w-20 h-20 rounded-3xl bg-gradient-to-br from-emerald-500 to-teal-600 shadow-lg mb-4">
            <PiggyBank className="w-10 h-10 text-white" />
          </div>
          <h1 className="text-4xl font-bold text-gray-900 dark:text-white mb-2">meu financeiro</h1>
          <p className="text-gray-600 dark:text-gray-400">Controle suas finanças com inteligência</p>
        </div>

        <div className="bg-white/80 dark:bg-gray-800/80 backdrop-blur-sm rounded-3xl shadow-xl p-8 mb-6 border border-white/20 dark:border-gray-700">
          <div className="space-y-4 mb-8">
            <div className="flex items-center gap-3 p-3 rounded-xl bg-emerald-50">
              <div className="w-10 h-10 rounded-xl bg-emerald-100 flex items-center justify-center">
                <TrendingUp className="w-5 h-5 text-emerald-600" />
              </div>
              <div className="flex-1">
                <p className="text-sm font-medium text-gray-900 dark:text-white">Receitas</p>
                <p className="text-xs text-gray-600 dark:text-gray-400">Acompanhe seus ganhos</p>
              </div>
            </div>

            <div className="flex items-center gap-3 p-3 rounded-xl bg-red-50">
              <div className="w-10 h-10 rounded-xl bg-red-100 flex items-center justify-center">
                <TrendingDown className="w-5 h-5 text-red-600" />
              </div>
              <div className="flex-1">
                <p className="text-sm font-medium text-gray-900 dark:text-white">Despesas</p>
                <p className="text-xs text-gray-600 dark:text-gray-400">Controle seus gastos</p>
              </div>
            </div>

            <div className="flex items-center gap-3 p-3 rounded-xl bg-violet-50">
              <div className="w-10 h-10 rounded-xl bg-violet-100 flex items-center justify-center">
                <PiggyBank className="w-5 h-5 text-violet-600" />
              </div>
              <div className="flex-1">
                <p className="text-sm font-medium text-gray-900 dark:text-white">Cofrinho</p>
                <p className="text-xs text-gray-600 dark:text-gray-400">Economize para o futuro</p>
              </div>
            </div>
          </div>

          <button
            onClick={redirectToLogin}
            className="w-full bg-gradient-to-r from-emerald-500 to-teal-600 text-white font-semibold py-4 rounded-2xl shadow-lg hover:shadow-xl transition-all duration-200 hover:scale-105 flex items-center justify-center gap-2"
          >
            <Sparkles className="w-5 h-5" />
            Entrar com Google
          </button>

          <div className="flex justify-center mt-4">
            <InstallButton />
          </div>
        </div>

        <p className="text-center text-sm text-gray-500 dark:text-gray-400">
          Gerencie suas finanças mensais de forma simples e eficiente
        </p>
      </div>
    </div>
  );
}

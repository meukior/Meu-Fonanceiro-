import { useState, useEffect } from "react";
import { useAuth } from "@getmocha/users-service/react";
import { LogOut, PiggyBank, Moon, Sun } from "lucide-react";
import { useTheme } from "@/react-app/contexts/ThemeContext";
import MonthSelector from "./MonthSelector";
import TransactionList from "./TransactionList";
import SavingsPanel from "./SavingsPanel";
import AddTransactionModal from "./AddTransactionModal";
import AddSavingsModal from "./AddSavingsModal";
import BalanceSummary from "./BalanceSummary";
import InstallButton from "./InstallButton";
import AdSenseModal from "./AdSenseModal";

export default function Dashboard() {
  const { logout, user } = useAuth();
  const { isDarkMode, toggleTheme } = useTheme();
  const currentDate = new Date();
  const [selectedMonth, setSelectedMonth] = useState(currentDate.getMonth() + 1);
  const [selectedYear, setSelectedYear] = useState(currentDate.getFullYear());
  const [isAddTransactionOpen, setIsAddTransactionOpen] = useState(false);
  const [isAddSavingsOpen, setIsAddSavingsOpen] = useState(false);
  const [refreshKey, setRefreshKey] = useState(0);
  const [isAdOpen, setIsAdOpen] = useState(false);

  useEffect(() => {
    const adInterval = setInterval(() => {
      setIsAdOpen(true);
    }, 30000);

    return () => clearInterval(adInterval);
  }, []);

  const handleTransactionAdded = () => {
    setRefreshKey((prev) => prev + 1);
    setIsAddTransactionOpen(false);
  };

  const handleSavingsAdded = () => {
    setRefreshKey((prev) => prev + 1);
    setIsAddSavingsOpen(false);
  };

  const handleTransactionDeleted = () => {
    setRefreshKey((prev) => prev + 1);
  };

  const handleSavingsDeleted = () => {
    setRefreshKey((prev) => prev + 1);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-emerald-50 via-teal-50 to-cyan-50 dark:from-gray-900 dark:via-gray-800 dark:to-gray-900 transition-colors duration-300">
      <header className="bg-white/80 dark:bg-gray-800/80 backdrop-blur-sm border-b border-emerald-100 dark:border-gray-700 sticky top-0 z-10 shadow-sm">
        <div className="max-w-7xl mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-emerald-500 to-teal-600 flex items-center justify-center shadow-md">
              <PiggyBank className="w-6 h-6 text-white" />
            </div>
            <div>
              <h1 className="text-xl font-bold text-gray-900 dark:text-white">meu financeiro</h1>
              <p className="text-xs text-gray-600 dark:text-gray-400">{user?.email}</p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <button
              onClick={toggleTheme}
              className="p-2 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-xl transition-colors"
              aria-label="Toggle dark mode"
            >
              {isDarkMode ? (
                <Sun className="w-5 h-5 text-yellow-500" />
              ) : (
                <Moon className="w-5 h-5 text-gray-700" />
              )}
            </button>
            <InstallButton />
            <button
              onClick={logout}
              className="flex items-center gap-2 px-4 py-2 text-sm text-gray-700 dark:text-gray-300 hover:text-gray-900 dark:hover:text-white hover:bg-gray-100 dark:hover:bg-gray-700 rounded-xl transition-colors"
            >
              <LogOut className="w-4 h-4" />
              Sair
            </button>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 py-6 space-y-6">
        <MonthSelector
          selectedMonth={selectedMonth}
          selectedYear={selectedYear}
          onMonthChange={setSelectedMonth}
          onYearChange={setSelectedYear}
        />

        <BalanceSummary
          month={selectedMonth}
          year={selectedYear}
          refreshKey={refreshKey}
        />

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <div className="lg:col-span-2">
            <TransactionList
              month={selectedMonth}
              year={selectedYear}
              refreshKey={refreshKey}
              onTransactionDeleted={handleTransactionDeleted}
              onAddTransaction={() => setIsAddTransactionOpen(true)}
            />
          </div>
          <div>
            <SavingsPanel
              refreshKey={refreshKey}
              onSavingsDeleted={handleSavingsDeleted}
              onAddSavings={() => setIsAddSavingsOpen(true)}
            />
          </div>
        </div>
      </main>

      <AddTransactionModal
        isOpen={isAddTransactionOpen}
        onClose={() => setIsAddTransactionOpen(false)}
        onTransactionAdded={handleTransactionAdded}
        month={selectedMonth}
        year={selectedYear}
      />

      <AddSavingsModal
        isOpen={isAddSavingsOpen}
        onClose={() => setIsAddSavingsOpen(false)}
        onSavingsAdded={handleSavingsAdded}
      />

      <AdSenseModal
        isOpen={isAdOpen}
        onClose={() => setIsAdOpen(false)}
      />
    </div>
  );
}

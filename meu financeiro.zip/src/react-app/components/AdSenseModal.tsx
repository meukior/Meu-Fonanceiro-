import { useEffect, useState } from "react";
import { X } from "lucide-react";

interface AdSenseModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export default function AdSenseModal({ isOpen, onClose }: AdSenseModalProps) {
  const [countdown, setCountdown] = useState(5);

  useEffect(() => {
    if (!isOpen) {
      setCountdown(5);
      return;
    }

    const interval = setInterval(() => {
      setCountdown((prev) => {
        if (prev <= 1) {
          clearInterval(interval);
          return 0;
        }
        return prev - 1;
      });
    }, 1000);

    return () => clearInterval(interval);
  }, [isOpen]);

  useEffect(() => {
    if (isOpen && countdown === 0) {
      // Load AdSense ads when modal opens and countdown finishes
      try {
        (window as any).adsbygoogle = (window as any).adsbygoogle || [];
        (window as any).adsbygoogle.push({});
      } catch (e) {
        console.error("Error loading AdSense:", e);
      }
    }
  }, [isOpen, countdown]);

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black/70 backdrop-blur-sm flex items-center justify-center p-4 z-50">
      <div className="bg-white dark:bg-gray-800 rounded-3xl shadow-2xl max-w-lg w-full overflow-hidden">
        <div className="relative bg-gradient-to-br from-violet-500 to-purple-600 p-6 text-white">
          {countdown === 0 && (
            <button
              onClick={onClose}
              className="absolute top-4 right-4 p-2 bg-white/20 hover:bg-white/30 rounded-xl transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          )}
          {countdown > 0 && (
            <div className="text-center space-y-4">
              <div className="text-4xl font-bold">📺</div>
              <p className="text-lg">Aguarde um momento...</p>
              <div className="mt-4">
                <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-white/20 backdrop-blur-sm">
                  <span className="text-3xl font-bold">{countdown}</span>
                </div>
              </div>
            </div>
          )}
        </div>
        
        {countdown === 0 && (
          <div className="p-6 bg-white dark:bg-gray-800">
            {/* Google AdSense Ad Unit */}
            <ins
              className="adsbygoogle"
              style={{ display: "block" }}
              data-ad-client="ca-pub-XXXXXXXXXXXXXXXX"
              data-ad-slot="XXXXXXXXXX"
              data-ad-format="auto"
              data-full-width-responsive="true"
            />
          </div>
        )}
        
        <div className="p-4 bg-gradient-to-br from-emerald-50 to-teal-50 dark:from-gray-700 dark:to-gray-800 border-t border-gray-200 dark:border-gray-700">
          <p className="text-center text-sm text-gray-700 dark:text-gray-300">
            💡 Este app é gratuito e mantido por anúncios
          </p>
        </div>
      </div>
    </div>
  );
}

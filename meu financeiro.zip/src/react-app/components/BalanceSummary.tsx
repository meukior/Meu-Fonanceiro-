import { useEffect, useState } from "react";
import { TrendingUp, TrendingDown, Wallet } from "lucide-react";
import type { Transaction } from "@/shared/types";

interface BalanceSummaryProps {
  month: number;
  year: number;
  refreshKey: number;
}

export default function BalanceSummary({ month, year, refreshKey }: BalanceSummaryProps) {
  const [transactions, setTransactions] = useState<Transaction[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchTransactions = async () => {
      setLoading(true);
      try {
        const response = await fetch(`/api/transactions?month=${month}&year=${year}`);
        const data = await response.json();
        setTransactions(data);
      } catch (error) {
        console.error("Error fetching transactions:", error);
      } finally {
        setLoading(false);
      }
    };

    fetchTransactions();
  }, [month, year, refreshKey]);

  const income = transactions
    .filter((t) => t.type === "income")
    .reduce((sum, t) => sum + t.amount, 0);

  const expenses = transactions
    .filter((t) => t.type === "expense")
    .reduce((sum, t) => sum + t.amount, 0);

  const balance = income - expenses;

  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat("pt-BR", {
      style: "currency",
      currency: "BRL",
    }).format(value);
  };

  if (loading) {
    return (
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {[1, 2, 3].map((i) => (
          <div key={i} className="bg-white/80 dark:bg-gray-800/80 backdrop-blur-sm rounded-2xl shadow-lg p-6 border border-white/20 dark:border-gray-700 animate-pulse">
            <div className="h-4 bg-gray-200 rounded w-20 mb-2"></div>
            <div className="h-8 bg-gray-200 rounded w-32"></div>
          </div>
        ))}
      </div>
    );
  }

  return (
    <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
      <div className="bg-gradient-to-br from-emerald-500 to-teal-600 rounded-2xl shadow-lg p-6 text-white">
        <div className="flex items-center justify-between mb-2">
          <p className="text-emerald-100 text-sm font-medium">Receitas</p>
          <div className="w-10 h-10 rounded-xl bg-white/20 backdrop-blur-sm flex items-center justify-center">
            <TrendingUp className="w-5 h-5" />
          </div>
        </div>
        <p className="text-3xl font-bold">{formatCurrency(income)}</p>
      </div>

      <div className="bg-gradient-to-br from-red-500 to-pink-600 rounded-2xl shadow-lg p-6 text-white">
        <div className="flex items-center justify-between mb-2">
          <p className="text-red-100 text-sm font-medium">Despesas</p>
          <div className="w-10 h-10 rounded-xl bg-white/20 backdrop-blur-sm flex items-center justify-center">
            <TrendingDown className="w-5 h-5" />
          </div>
        </div>
        <p className="text-3xl font-bold">{formatCurrency(expenses)}</p>
      </div>

      <div className={`rounded-2xl shadow-lg p-6 text-white ${
        balance >= 0
          ? "bg-gradient-to-br from-violet-500 to-purple-600"
          : "bg-gradient-to-br from-orange-500 to-red-600"
      }`}>
        <div className="flex items-center justify-between mb-2">
          <p className="text-white/90 text-sm font-medium">
            {balance >= 0 ? "Saldo" : "Saldo Devedor"}
          </p>
          <div className="w-10 h-10 rounded-xl bg-white/20 backdrop-blur-sm flex items-center justify-center">
            <Wallet className="w-5 h-5" />
          </div>
        </div>
        <p className="text-3xl font-bold">{formatCurrency(Math.abs(balance))}</p>
      </div>
    </div>
  );
}

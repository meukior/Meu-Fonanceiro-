import z from "zod";

export const TransactionSchema = z.object({
  id: z.number(),
  user_id: z.string(),
  amount: z.number(),
  type: z.enum(["income", "expense"]),
  description: z.string().optional(),
  month: z.number().min(1).max(12),
  year: z.number(),
  created_at: z.string(),
  updated_at: z.string(),
});

export const CreateTransactionSchema = z.object({
  amount: z.number().positive(),
  type: z.enum(["income", "expense"]),
  description: z.string().optional(),
  month: z.number().min(1).max(12),
  year: z.number(),
});

export const SavingsSchema = z.object({
  id: z.number(),
  user_id: z.string(),
  amount: z.number(),
  description: z.string().optional(),
  created_at: z.string(),
  updated_at: z.string(),
});

export const CreateSavingsSchema = z.object({
  amount: z.number().positive(),
  description: z.string().optional(),
});

export type Transaction = z.infer<typeof TransactionSchema>;
export type CreateTransaction = z.infer<typeof CreateTransactionSchema>;
export type Savings = z.infer<typeof SavingsSchema>;
export type CreateSavings = z.infer<typeof CreateSavingsSchema>;

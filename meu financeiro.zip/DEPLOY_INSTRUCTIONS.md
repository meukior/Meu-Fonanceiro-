# Guia de Deploy - meu financeiro PWA

Este guia te ajudará a fazer deploy do app no seu próprio domínio usando Cloudflare Workers.

## Pré-requisitos

1. **Conta Cloudflare** (gratuita): https://dash.cloudflare.com/sign-up
2. **Domínio próprio**: Você pode comprar em:
   - Registro.br (para .br)
   - GoDaddy
   - Namecheap
   - Ou qualquer outro registrar
3. **Node.js instalado**: https://nodejs.org/ (versão 18 ou superior)

## Passo 1: Configurar DNS no Cloudflare

1. Faça login no Cloudflare
2. Clique em "Add a Site"
3. Digite seu domínio (ex: meusite.com.br)
4. Escolha o plano gratuito
5. Cloudflare mostrará os nameservers (DNS)
6. Vá ao seu registrar de domínio (onde você comprou o domínio)
7. Atualize os nameservers para os fornecidos pelo Cloudflare
8. Aguarde a propagação (pode levar até 24 horas, mas geralmente é rápido)

## Passo 2: Baixar o Código Fonte

Baixe todos os arquivos deste projeto para seu computador:

```
meu-financeiro/
├── public/
│   ├── icon-192.png
│   ├── icon-512.png
│   ├── manifest.json
│   └── sw.js
├── src/
│   ├── react-app/
│   │   ├── components/
│   │   ├── contexts/
│   │   ├── pages/
│   │   ├── App.tsx
│   │   ├── index.css
│   │   ├── main.tsx
│   │   └── vite-env.d.ts
│   ├── shared/
│   │   └── types.ts
│   └── worker/
│       ├── env.d.ts
│       └── index.ts
├── index.html
├── package.json
├── tailwind.config.js
├── tsconfig.json
├── vite.config.ts
└── wrangler.json
```

## Passo 3: Instalar Dependências

Abra o terminal na pasta do projeto e execute:

```bash
npm install
```

## Passo 4: Configurar Cloudflare D1 Database

1. Instale o Wrangler CLI globalmente:
```bash
npm install -g wrangler
```

2. Faça login no Cloudflare:
```bash
wrangler login
```

3. Crie o banco de dados D1:
```bash
wrangler d1 create meu-financeiro-db
```

4. O comando acima retornará informações do database. Copie o `database_id`.

5. Atualize o arquivo `wrangler.json` com o `database_id`:
```json
{
  "name": "meu-financeiro",
  "compatibility_date": "2024-01-01",
  "d1_databases": [
    {
      "binding": "DB",
      "database_name": "meu-financeiro-db",
      "database_id": "COLE_O_DATABASE_ID_AQUI"
    }
  ]
}
```

6. Execute as migrações do banco de dados:
```bash
wrangler d1 execute meu-financeiro-db --remote --command "CREATE TABLE transactions (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id TEXT NOT NULL,
  amount REAL NOT NULL,
  type TEXT NOT NULL,
  description TEXT,
  month INTEGER NOT NULL,
  year INTEGER NOT NULL,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
);"

wrangler d1 execute meu-financeiro-db --remote --command "CREATE TABLE savings (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id TEXT NOT NULL,
  amount REAL NOT NULL,
  description TEXT,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
);"
```

## Passo 5: Configurar Autenticação (Mocha Users Service)

O app usa o serviço de autenticação da Mocha. Para configurar:

1. Entre em contato com o suporte da Mocha para obter:
   - `MOCHA_USERS_SERVICE_API_URL`
   - `MOCHA_USERS_SERVICE_API_KEY`

2. Configure os secrets no Cloudflare:
```bash
wrangler secret put MOCHA_USERS_SERVICE_API_URL
# Cole a URL quando solicitado

wrangler secret put MOCHA_USERS_SERVICE_API_KEY
# Cole a API Key quando solicitado
```

**Alternativa - Usar outro serviço de autenticação:**
Se preferir não usar o Mocha Users Service, você pode integrar outro provedor como:
- Firebase Authentication
- Auth0
- Supabase Auth
- AWS Cognito

Neste caso, você precisará modificar os arquivos em `src/worker/index.ts` e os componentes React que usam `@getmocha/users-service`.

## Passo 6: Configurar Google AdSense

1. Crie uma conta no Google AdSense: https://www.google.com/adsense/
2. Adicione seu domínio e aguarde aprovação
3. Crie uma unidade de anúncio
4. Copie seu Publisher ID (formato: ca-pub-XXXXXXXXXXXXXXXX)

5. Configure o secret:
```bash
wrangler secret put GOOGLE_ADSENSE_CLIENT_ID
# Cole seu Publisher ID quando solicitado
```

6. Atualize o arquivo `index.html` com seu Publisher ID:
```html
<script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=SEU_PUBLISHER_ID" crossorigin="anonymous"></script>
```

7. Atualize o arquivo `src/react-app/components/AdSenseModal.tsx` com seus valores:
```typescript
data-ad-client="SEU_PUBLISHER_ID"
data-ad-slot="SEU_AD_SLOT_ID"
```

## Passo 7: Deploy para Cloudflare Workers

1. Build do projeto:
```bash
npm run build
```

2. Deploy para Cloudflare:
```bash
wrangler deploy
```

3. Após o deploy, o Wrangler mostrará a URL do seu worker (ex: meu-financeiro.seu-usuario.workers.dev)

## Passo 8: Conectar seu Domínio Personalizado

1. No Cloudflare Dashboard, vá para Workers & Pages
2. Clique no seu worker (meu-financeiro)
3. Vá para "Triggers" > "Custom Domains"
4. Clique em "Add Custom Domain"
5. Digite seu domínio (ex: app.meusite.com.br ou meusite.com.br)
6. Confirme

O Cloudflare configurará automaticamente o DNS e SSL/HTTPS.

## Passo 9: Atualizar URLs do App

Atualize o arquivo `index.html` com seu domínio real:

```html
<meta property="og:url" content="https://seu-dominio.com.br" />
```

Faça deploy novamente:
```bash
npm run build
wrangler deploy
```

## Passo 10: Verificação Final

1. Acesse seu domínio no navegador
2. Teste o login com Google
3. Teste adicionar transações e economias
4. Teste instalar o PWA no seu dispositivo
5. Verifique se os anúncios do AdSense aparecem (pode levar algumas horas após aprovação)

## Comandos Úteis

```bash
# Desenvolvimento local
npm run dev

# Ver logs em tempo real
wrangler tail

# Executar queries no banco de dados
wrangler d1 execute meu-financeiro-db --remote --command "SELECT * FROM transactions LIMIT 10"

# Ver secrets configurados
wrangler secret list

# Atualizar um secret
wrangler secret put NOME_DO_SECRET
```

## Troubleshooting

### Erro de autenticação
- Verifique se os secrets MOCHA_USERS_SERVICE_API_URL e MOCHA_USERS_SERVICE_API_KEY estão configurados
- Verifique se os valores estão corretos

### Banco de dados não funciona
- Verifique se o database_id no wrangler.json está correto
- Verifique se as migrações foram executadas com sucesso

### AdSense não aparece
- Pode levar 24-48h para o AdSense começar a servir anúncios após aprovação
- Verifique se seu site foi aprovado pelo AdSense
- Verifique se o código do AdSense está correto

### PWA não instala
- Verifique se o site está rodando com HTTPS (Cloudflare faz isso automaticamente)
- Verifique se os ícones em public/icon-*.png existem
- Verifique se o service worker está registrado corretamente

## Custos

- **Cloudflare Workers**: Gratuito até 100.000 requisições/dia
- **Cloudflare D1**: Gratuito até 5GB de armazenamento e 5 milhões de leituras/dia
- **Domínio**: Varia de R$ 40-150/ano dependendo da extensão (.com.br, .com, etc)

## Suporte

Se tiver problemas durante o deploy:
1. Verifique os logs com `wrangler tail`
2. Consulte a documentação do Cloudflare Workers: https://developers.cloudflare.com/workers/
3. Comunidade Cloudflare Discord: https://discord.gg/cloudflaredev

---

Boa sorte com seu projeto! 🚀


DROP TABLE subscriptions;

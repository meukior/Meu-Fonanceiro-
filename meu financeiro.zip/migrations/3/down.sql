
DROP INDEX idx_subscriptions_is_active;
DROP INDEX idx_subscriptions_user_id;
DROP TABLE subscriptions;

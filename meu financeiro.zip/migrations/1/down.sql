
DROP INDEX idx_transactions_month_year;
DROP INDEX idx_transactions_user_id;
DROP TABLE transactions;


DROP INDEX idx_savings_user_id;
DROP TABLE savings;

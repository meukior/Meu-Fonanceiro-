
ALTER TABLE subscriptions DROP COLUMN mp_preference_id;

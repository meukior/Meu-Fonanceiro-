
ALTER TABLE subscriptions ADD COLUMN mp_preference_id TEXT;
